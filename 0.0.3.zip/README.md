React Revolution 
===

WordPress child theme for [wp-react-theme](https://github.com/spacedmonkey/wp-react-theme).
