/**
 * Internal dependencies
 */
import './theme.css';
